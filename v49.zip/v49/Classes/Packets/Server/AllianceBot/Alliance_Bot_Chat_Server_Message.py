from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class AllianceBotChatServerMessage(PiranhaMessage):

    def __init__(self, client, player, bot_msg_content):
        super().__init__(b'')
        self.client = client
        self.bot_msg_content = bot_msg_content
        self.id = 24312
        self.player = player

    def encode(self):
        print(f"DEBUG: Кодируем бот сообщение: '{self.bot_msg_content}'")
        db = DatabaseHandler()
        db.GetmsgCount(self, self.player.AllianceID[1])
        print(f"DEBUG: MessageCount: {self.MessageCount}")
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(self.MessageCount)
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeString("Bot")
        self.writeVInt(3)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString(self.bot_msg_content)
        print(f"DEBUG: Закодировано {len(self.messagePayload)} байт")

    def send(self):
        print(f"DEBUG: Отправляем бот сообщение длиной {len(self.messagePayload)} байт")
        print(f"DEBUG: ID сообщения: {self.id}")
        self.client.send(self.messagePayload)