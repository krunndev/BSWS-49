import datetime
import random
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage

class LobbyInfoMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def formatLobbyText(self, player):
        player_count = ClientsManager.GetCount()
        ping = random.randint(20, 50)
        
        text = f"BSWS V49\n"
        text += f"Игроков онлайн: {player_count}\n"
        text += f"Пинг: {ping}мс\n"
        text += f"Время сервера: {datetime.datetime.now().strftime('%H:%M:%S')}\n"
        
        text += "\n" * 30
        
        return text

    def encode(self, fields, player):
        self.writeVInt(ClientsManager.GetCount())
        lobby_text = self.formatLobbyText(player)
        self.writeString(lobby_text)
        self.writeVInt(0)

    def decode(self):
        fields = {}
        fields["PlayerCount"] = self.readVInt()
        fields["Text"] = self.readString()
        fields["Unk1"] = self.readVInt()
        super().decode(fields)
        return fields

    def getMessageType(self):
        return 23457

    def getMessageVersion(self):
        return self.messageVersion