from Classes.Messaging import Messaging
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler, ClubDatabaseHandler
from Classes.Packets.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
import json

class ChatToAllianceStreamMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Message"] = self.readString()
        
        print(f"DEBUG: Декодированное сообщение: '{fields['Message']}'")
        
        if fields["Message"].lower().startswith('/login '):
            fields["IsLoginCommand"] = True
            fields["LoginToken"] = fields["Message"].split(' ')[1]
            print(f"DEBUG: Обнаружена команда логина, токен: '{fields['LoginToken']}'")
        else:
            print("DEBUG: Обычное сообщение, не команда")
        
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        print(f"DEBUG: Получено сообщение: '{fields['Message']}'")
        print(f"DEBUG: IsLoginCommand: {fields.get('IsLoginCommand', False)}")
        
        if fields.get("IsLoginCommand", False):
            print(f"DEBUG: Обрабатываем команду логина с токеном: {fields['LoginToken']}")
            print(f"DEBUG: Текущий Player ID: {calling_instance.player.ID}")
            
            db = DatabaseHandler()
            
            # Находим игрока по токену
            target_player_id = db.getPlayerByToken(fields["LoginToken"])
            
            if target_player_id:
                print("DEBUG: Токен верный, выполняем вход в аккаунт")
                try:
                    # Загружаем данные найденного аккаунта
                    db.loadAccount(calling_instance.player, target_player_id)
                    print(f"DEBUG: Успешно загружены данные аккаунта {calling_instance.player.Name}")
                    
                    # Отправляем сообщение об успешном входе
                    success_msg = f"✅ Успешный вход в аккаунт {calling_instance.player.Name}!"
                    bot_message = AllianceBotChatServerMessage(
                        calling_instance.client, 
                        calling_instance.player, 
                        success_msg
                    )
                    bot_message.encode()
                    bot_message.send()
                    
                    # Отправляем обновленные данные клиенту
                    from Classes.Messaging import Messaging
                    update_fields = {"Socket": calling_instance.client}
                    Messaging.sendMessage(24101, update_fields, cryptoInit, calling_instance.player)
                    
                    return  # Выходим, чтобы не отправлять обычное сообщение
                    
                except Exception as e:
                    print(f"DEBUG: Ошибка при загрузке аккаунта: {e}")
                    error_msg = "❌ Ошибка при загрузке аккаунта!"
                    bot_message = AllianceBotChatServerMessage(
                        calling_instance.client, 
                        calling_instance.player, 
                        error_msg
                    )
                    bot_message.encode()
                    bot_message.send()
                    return
            else:
                print("DEBUG: Токен неверный, отправляем ошибку")
                error_msg = "❌ Ошибка: неверный токен!"
                bot_message = AllianceBotChatServerMessage(
                    calling_instance.client, 
                    calling_instance.player, 
                    error_msg
                )
                bot_message.encode()
                bot_message.send()
                return

        # Обычная обработка сообщений (если это не команда входа)
        fields["Socket"] = calling_instance.client
        
        # Проверяем, состоит ли игрок в клубе
        if calling_instance.player.AllianceID[1] == 0:
            print("DEBUG: Игрок не состоит в клубе, сообщение не отправлено")
            return
            
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        clubdb_instance = ClubDatabaseHandler()
        
        try:
            club_result = clubdb_instance.getClubWithLowID(calling_instance.player.AllianceID[1])
            if not club_result or len(club_result) == 0:
                print("DEBUG: Клуб не найден")
                return
                
            clubData = json.loads(club_result[0][1])
            
            # Проверяем, что игрок есть в списке участников клуба
            if str(playerData["ID"][1]) not in clubData["Members"]:
                print("DEBUG: Игрок не найден в списке участников клуба")
                return
                
            MessageCount = len(clubData["ChatData"])
            Role = clubData["Members"][str(playerData["ID"][1])]["Role"]
            message = {
                'StreamType': 2,
                'StreamID': [0, MessageCount + 1],
                'PlayerID': calling_instance.player.ID,
                'PlayerName': calling_instance.player.Name,
                'PlayerRole': Role,
                'Message': fields["Message"]
            }
            clubData["ChatData"].append(message)
            clubdb_instance.updateClubData(clubData, calling_instance.player.AllianceID[1])
            Messaging.sendMessage(24311, fields, cryptoInit, calling_instance.player)
            
        except Exception as e:
            print(f"DEBUG: Ошибка при обработке сообщения в клубе: {e}")
            return

    def getMessageType(self):
        return 14315

    def getMessageVersion(self):
        return self.messageVersion