from Classes.Messaging import Messaging
from Classes.Packets.PiranhaMessage import PiranhaMessage
import Configuration
from Database.DatabaseHandler import DatabaseHandler
from Static.StaticData import StaticData
#from Classes.Files.Classes.Cards import Cards
#from Classes.FilesStarrDrops.Classes.GenStarDropRewards import genStarDropReward
import json

class SetSupportedCreatorMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Message"] = self.readString()
        print(f"Получено сообщение: '{fields['Message']}'")
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        db_instance = DatabaseHandler()
        player_data = db_instance.getPlayer(calling_instance.player.ID)

        msg = fields["Message"].strip().lower()

        # Обработка фиксированных кодов из настроек
        if msg in Configuration.settings.get("CreatorsCodesKittys", []) or msg in Configuration.settings.get("CreatorsCodesCats", []):
            player_data["Gems"] += 100
            player_data["ContentCreator"] = msg
            db_instance.updatePlayerData(player_data, calling_instance)
            fields.update({
                "Command": {"ID": 215},
                "PlayerID": calling_instance.player.ID,
                "SupportedCreator": fields["Message"]
            })
            Messaging.sendMessage(24111, fields, cryptoInit)
            return

        # Пример фиксированного промокода MMA
        elif msg == "mma":
            if "UsedPromoCodes" not in player_data:
                player_data["UsedPromoCodes"] = []
            if "MMA" in player_data["UsedPromoCodes"]:
                print("Промокод MMA уже активирован либо не существует.")
                Messaging.sendMessage(28686, fields, cryptoInit)
                return
            else:
                player_data["UsedPromoCodes"].append("MMA")
                player_data["OwnedThumbnails"].append(371)
                player_data["OwnedSkins"].append(743)
                player_data["OwnedBrawlers"][15] = {
                    'CardID': 60, 'Trophies': 0, 'HighestTrophies': 0,
                    'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0
                }
                player_data["OwnedPins"].append(1494)
                player_data["delivery_items"] = {'Boxes': []}

                rewards = [
                    {'Amount': 1, 'DataRef': [29, 743], 'RewardID': 9},
                    {'Amount': 1, 'DataRef': [28, 371], 'RewardID': 11},
                    {'Amount': 1, 'DataRef': [52, 1494], 'RewardID': 11}
                ]

                for reward in rewards:
                    box = {'Type': 100, 'Items': [reward]}
                    player_data["delivery_items"]['Boxes'].append(box)

                db_instance.updatePlayerData(player_data, calling_instance)
                fields.update({
                    "Command": {"ID": 203},
                    "PlayerID": calling_instance.player.ID,
                    "SupportedCreator": fields["Message"]
                })
                Messaging.sendMessage(24111, fields, cryptoInit)
                return

        # Еще примеры фиксированных промокодов (loadcreatorsicon, 4e5462bf6240, lastvontik, tt:sunex, kit, 666)
        elif msg == "loadcreatorsicon":
            if 186 not in player_data["OwnedThumbnails"]:
                player_data["OwnedThumbnails"].append(186)
            player_data["delivery_items"] = {'Boxes': []}
            box = {'Type': 100, 'Items': [{'Amount': 1, 'DataRef': [28, 186], 'RewardID': 11}]}
            player_data["delivery_items"]['Boxes'].append(box)
            db_instance.updatePlayerData(player_data, calling_instance)
            fields.update({
                "Command": {"ID": 203},
                "PlayerID": calling_instance.player.ID,
                "SupportedCreator": fields["Message"]
            })
            Messaging.sendMessage(24111, fields, cryptoInit)
            return

        elif msg == "4e5462bf6240":
            player_data["ContentCreator"] = "4e5462bf6240"
            player_data["BrawlPass"] = True
            fields.update({
                "Command": {"ID": 215},
                "SupportedCreator": fields["Message"]
            })
            Messaging.sendMessage(24104, fields, cryptoInit)
            Messaging.sendMessage(24111, fields, cryptoInit)
            return

        elif msg == "lastvontik":
            player_data["ContentCreator"] = "lastvontik"
            player_data["Gems"] += 25
            fields.update({
                "Command": {"ID": 215},
                "SupportedCreator": fields["Message"]
            })
            Messaging.sendMessage(24111, fields, cryptoInit)
            return

        elif msg == "tt:sunex":
            player_data["ContentCreator"] = "TT:Sunex"
            player_data["Gems"] += 25
            fields.update({
                "Command": {"ID": 215},
                "SupportedCreator": fields["Message"]
            })
            Messaging.sendMessage(24111, fields, cryptoInit)
            return

        elif msg == "":
            player_data["ContentCreator"] = ""
            fields.update({
                "Command": {"ID": 215},
                "SupportedCreator": fields["Message"]
            })
            Messaging.sendMessage(24111, fields, cryptoInit)
            return

        elif msg == "kit":
            player_data["ContentCreator"] = "KIT"
            player_data["Gems"] += 25
            fields.update({
                "Command": {"ID": 215},
                "SupportedCreator": fields["Message"]
            })
            Messaging.sendMessage(24111, fields, cryptoInit)
            return

        elif msg == "666":
            player_data["ContentCreator"] = "666"
            player_data["Coins"] = 666
            player_data["Name"] = "666"
            player_data["Gems"] = 666
            player_data["Trophies"] = 666
            fields.update({
                "Command": {"ID": 215},
                "SupportedCreator": fields["Message"]
            })
            Messaging.sendMessage(24104, fields, cryptoInit)
            return

        # Если не один из фиксированных кодов, пытаемся найти в JSON
        else:
            promo_code = fields["Message"].strip()
            print(f"⏳ Проверка JSON промокодов... Введено: '{promo_code}'")

            try:
                with open("Codes.json", "r", encoding="utf-8") as f:
                    codes_data = json.load(f)
                print("✅ Codes.json загружен успешно.")
            except Exception as e:
                print(f"❌ Ошибка при чтении Codes.json: {e}")
                Messaging.sendMessage(28686, fields, cryptoInit)
                return

            found = False

            for code in codes_data.get("Codes", []):
                code_match = code.get("Code", "").strip().lower()
                if code_match == promo_code.lower():
                    found = True
                    print(f"✅ Найден промокод: {code['Code']}")

                    if "UsedPromoCodes" not in player_data:
                        player_data["UsedPromoCodes"] = []

                    if promo_code.upper() in player_data["UsedPromoCodes"]:
                        print("⚠️ Промокод уже был использован.")
                        Messaging.sendMessage(28686, fields, cryptoInit)
                        return

                    player_data["UsedPromoCodes"].append(promo_code.upper())

                    if "delivery_items" not in player_data:
                        player_data["delivery_items"] = {"Boxes": []}

                    box = {"Type": 100, "Items": []}
                    item_type = code["ItemID"]

                    if item_type == 4:  # Skin
                        skin_id = code.get("ExtraID")
                        if skin_id and skin_id not in player_data["OwnedSkins"]:
                            player_data["OwnedSkins"].append(skin_id)
                        box["Items"].append({'Amount': 1, 'DataRef': [29, skin_id], 'RewardID': 9})

                    elif item_type == 19:  # Pin
                        pin_id = code.get("ExtraID")
                        if pin_id and pin_id not in player_data["OwnedPins"]:
                            player_data["OwnedPins"].append(pin_id)
                        box["Items"].append({'Amount': 1, 'DataRef': [52, pin_id], 'RewardID': 11})

                    elif item_type == 16:  # Gems
                        amount = code.get("Amount", 0)
                        player_data["Gems"] += amount
                        box["Items"].append({'Amount': amount, 'DataRef': [0, 0], 'RewardID': 8})

                    elif item_type == 25:  # Thumbnail
                        thumb_id = code.get("ExtraID")
                        if thumb_id and thumb_id not in player_data["OwnedThumbnails"]:
                            player_data["OwnedThumbnails"].append(thumb_id)
                        box["Items"].append({'Amount': 1, 'DataRef': [28, thumb_id], 'RewardID': 11})

                    elif item_type == 45:  # Bling
                        amount = code.get("Amount", 0)
                        player_data["Blings"] += amount
                        box["Items"].append({'Amount': amount, 'DataRef': [0, 0], 'RewardID': 25})

                    #elif item_type == 49:  # Starr Drop
                        #item = genStarDropReward(player_data)
                        #box["Items"].append(item)

                    elif item_type == 1:  # Coins
                        amount = code.get("Amount", 0)
                        player_data["Coins"] += amount
                        box["Items"].append({'Amount': amount, 'DataRef': [0, 0], 'RewardID': 7})

                    elif item_type == 3:  # Brawler
                        brawler_info = code.get("Brawler", [])
                        if len(brawler_info) > 1:
                            brawler_id = brawler_info[1]
                            power = code.get("Amount", 1)
                            player_data["OwnedBrawlers"][brawler_id] = {
                                'CardID': Cards.getBrawlerUnlockID(brawler_id),
                                'Trophies': 0,
                                'HighestTrophies': 0,
                                'PowerLevel': power,
                                'Mastery': 0,
                                'ClaimRewardsMastery': 0
                            }
                            box["Items"].append({'Amount': power, 'DataRef': [16, brawler_id], 'RewardID': 1})

                    if box["Items"]:
                        player_data["delivery_items"]["Boxes"].append(box)

                    fields.update({
                        "Command": {"ID": 203},
                        "PlayerID": calling_instance.player.ID,
                        "SupportedCreator": promo_code
                    })
                    db_instance.updatePlayerData(player_data, calling_instance)
                    Messaging.sendMessage(24111, fields, cryptoInit)
                    return

            if not found:
                print("❌ Промокод не найден.")
                fields["jopa"] = player_data.get("ContentCreator", "")
                Messaging.sendMessage(28686, fields, cryptoInit)

        db_instance.updatePlayerData(player_data, calling_instance)

    def getMessageType(self):
        return 18686

    def getMessageVersion(self):
        return self.messageVersion