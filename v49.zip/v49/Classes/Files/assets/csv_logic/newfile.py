import csv

def get_skins_id(csv_file_path='Classes/Commands/Client/skins.txt'):
    """
    Извлекает ID скинов из CSV-файла, где значение во втором столбце не 'true'
    
    Args:
        csv_file_path (str): Путь к CSV-файлу с информацией о скинах
    
    Returns:
        list: Список ID скинов, где enabled != 'true' (case insensitive)
    """
    skins_id = []
    
    try:
        with open(csv_file_path, mode='r', encoding='utf-8') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            
            # Пропускаем заголовки (первые 2 строки)
            next(csv_reader)  # Первая строка заголовка
            next(csv_reader)  # Вторая строка заголовка
            
            # Обрабатываем оставшиеся строки
            for line_num, row in enumerate(csv_reader, start=1):
                if not row:  # Пропускаем пустые строки
                    continue
                    
                # Проверяем второй столбец (индекс 1)
                if len(row) > 1 and row[1].lower() != 'true':
                    skins_id.append(line_num - 1)  # ID = номер строки - 2 заголовка + 1 (т.к. enumerate начинается с 1)
                
    except FileNotFoundError:
        print(f"Ошибка: Файл не найден по пути {csv_file_path}")
    except Exception as e:
        print(f"Произошла ошибка при обработке файла: {str(e)}")
    
    return skins_id

# Пример использования
if __name__ == "__main__":
    skins_ids = get_skins_id()
    print("Найденные ID скинов:", skins_ids)