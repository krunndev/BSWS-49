settings = {
    "DisableNagle": True,
    "PrintEnabled": True,
    "UseContentUpdater": False,
    "Proxy": True,
    "DumpPacket": False,
    "Blacklist": [24109],
    "DumpMajor": 49,
    "HankTimer": [2026, 12, 30, 11, 0, 0],
    "WillowCreators": [
    "iamfeelingbad", "t3stn3t", "set", "set", "set", "set", "set", 
    "set", "set", "set", "set", "set",
    "BrawlStars", "BSWS", "V49", "krunndev"],
    "Willow2LVLCreators": [],
    "Willow1LVLCreators": []
}