How to use:

put your files in ContentUpdater/Content

run ContentUpdater/Updater.py

after its done run ContentUpdater/Server.py

if you managed to deleted it by accident here what lastversion.txt should contains
